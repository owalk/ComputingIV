Oliver Walker

I used the string representation for my register bits becuase 
i've use strings a lot in the past and I am familiar with how
they work. It was easiest and fastest for me.

In my additional tests, I am testing that my step function 
works correctly on a 13 bit string and a 32 bit string. For
the 13 bit string, i step 3 times with a tap position at 6,
and for the 32 bit string i step 3 times with a tap position at
4.