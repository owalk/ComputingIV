/**********************************************************************
 *  N-Body Simulation ps3b-readme.txt template
 **********************************************************************/

Name: Oliver Walker
OS: Manjaro Linux
Machine (e.g., Dell Latitude, MacBook Pro): Built it. it has parts.
Text editor: emacs.
Hours to complete assignment (optional): a few.

/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/
 nope.

/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
 harrison disjardins gave me some help with the step function that i named movement.

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I thought this was a memory problem, but it might be from the graphics
library, still not sure though. When run my program, after a seemingly
random period of time my computer freezes. It's very annoying.
the same kind of freeze happens when i play games through wine and
play on linux sometimes so im guessing it's caused by a sfml dependancy that
play on linux and win also have. I dont think it's the program itself causing this.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
I felt like making another class. 
