Oliver Walker

Functionality of program:
Fully works. 

To ensure that the images get a fully random RGB color 
distribution, I am giving them very large LFSR seeds.
Especially so with the Password to seed convertor.
