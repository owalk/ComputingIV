Oliver Walker

I made a very simple dividing triangle fractal.
It finds the Center of the top, left, and right
corners and makes three triangles that all meet 
at that point. 3 or 4 recurrsions look the best.
the setup is very similar to the Sierpinski triangle.
infact, it's much easier to calculate then the Sierpinski triangle

***memory***

adding 10 more to the recurrsion depth took about 10 mb of ram. 
while stupidly adding 500 brought my computer to a adbrupt halt.

with my own version, the memory usage was basically the same.
(having the same amount of children nodes makes this make sense)

I put in around 4 hours for the sierpinski triangle.

tried and failed to do a very complex octogon fractal for maybe 8 hours.

did the current subdividing triangle fractal in 20 minutes.